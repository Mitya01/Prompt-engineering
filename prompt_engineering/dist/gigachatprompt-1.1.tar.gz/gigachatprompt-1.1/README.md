# prompt_engineering

A function that takes 2 arguments: credentials from GigaChat API and a job description and returns 5 screening questions.