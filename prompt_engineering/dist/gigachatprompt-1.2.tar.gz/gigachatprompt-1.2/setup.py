from setuptools import setup

setup(
    name='gigachatprompt',
    version='1.2',
    author='Mitya01',
    description='A function that takes 2 arguments: credentials from GigaChat API and a job description and returns 5 screening questions.'
)
